<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Include WordPress to use its functions
    require_once('../../../wp-load.php');

    // Get form data
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $phone = htmlspecialchars($_POST['phone']);

    $date = date("Y-m-d H:i:s");

    // Save data to a file
    $file = 'submissions.txt';
    $data = "Date: $date\nName: $name\nEmail: $email\nPhone: $phone\n---\n";
    file_put_contents($file, $data, FILE_APPEND);

    // Save data as a post in WordPress
    $new_post = array(
        'post_title'    => wp_strip_all_tags($name),
        'post_content'  => "Name: $name\nEmail: $email\nPhone: $phone",
        'post_status'   => 'publish', // Publish immediately, you can also use 'draft'
        'post_author'   => 1, // ID of the author (usually admin)
        'post_type'     => 'form_submission' // You can create a custom post type or use 'post'
    );

    // Insert the post into the database
    $post_id = wp_insert_post($new_post);

    if (!is_wp_error($post_id)) {
        // Additional fields (metadata)
        update_post_meta($post_id, 'email', $email);
        update_post_meta($post_id, 'phone', $phone);
    } else {
        echo "Error saving data to WordPress.";
    }

    // Send email
    $to = "vladyslav.s@thewhitelabelagency.com";
    $subject = "New form submission";
    $message = "You have received a new form submission:\n\n" . $data;
    $headers = "From: no-reply@yourdomain.com\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

    if (mail($to, $subject, $message, $headers)) {
        echo "Email sent successfully!";
    } else {
        echo "Failed to send email.";
    }

    // Send a message to Telegram
    $telegramToken = "8037835641:AAGgdpixuF6nEE42cBR73jVzXXV-V9-4tcQ"; // Replace with your token
    $chatId = "547849987"; // Replace with your chat_id
    $telegramMessage = "New form submission:\n\n" . $data;
    $url = "https://api.telegram.org/bot$telegramToken/sendMessage?chat_id=$chatId&text=" . urlencode($telegramMessage);
    file_get_contents($url);

    // Redirect to the thank-you page
    header("Location: /thank-you");
    exit();
} else {
    echo "Invalid request method";
}
?>
