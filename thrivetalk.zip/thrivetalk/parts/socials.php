<?php if ( have_rows( 'socials', 'options' ) ): ?>
	<ul class="socials">
		<?php while ( have_rows( 'socials', 'options' ) ): the_row(); ?>
		<?php $social_network = get_sub_field('social_network'); ?>
			<li class="socials__item">
				<a class="socials__link"
				   href="<?php the_sub_field( 'social_profile' ); ?>"
				   target="_blank"
				   aria-label="<?php echo $social_network['label']; ?>"
				   rel="noopener"><span aria-hidden="true" class="socials__icon fab fa-<?php echo $social_network['value']; ?>"></span>
				</a>
			</li>
		<?php endwhile; ?>
	</ul>
<?php endif; ?>

