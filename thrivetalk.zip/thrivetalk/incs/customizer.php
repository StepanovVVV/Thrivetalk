<?php
    add_action( 'customize_register', function ( WP_Customize_Manager $wp_customize ) {

	$wp_customize->add_section( 'custom_options_theme', array(
		'title' => __( 'Custom options', 'default' ),
		'priority' => 10,
	) );

	// phone
	$wp_customize->add_setting( 'custom_phone' );
	$wp_customize->add_control( 'custom_phone', array(
		'label' => __( 'Phoner', 'default' ),
		'section' => 'custom_options_theme',
	) );

	// youtube
	$wp_customize->add_setting( 'custom_youtube' );
	$wp_customize->add_control( 'custom_youtube', array(
		'label' => __( 'Youtube link', 'default' ),
		'section' => 'custom_options_theme',
	) );

	// facebook
	$wp_customize->add_setting( 'custom_facebook' );
	$wp_customize->add_control( 'custom_facebook', array(
		'label' => __( 'Facebook link', 'default' ),
		'section' => 'custom_options_theme',
	) );

	// instagram
	$wp_customize->add_setting( 'custom_instagram' );
	$wp_customize->add_control( 'custom_instagram', array(
		'label' => __( 'Instagram link', 'default' ),
		'section' => 'custom_options_theme',
	) );
} );

function custom_options_theme() {
	return array(
		'phone' => get_theme_mod( 'custom_phone' ),
		'youtube' => get_theme_mod( 'custom_youtube' ),
		'facebook' => get_theme_mod( 'custom_facebook' ),
		'instagram' => get_theme_mod( 'custom_instagram' ),
	);
}

// using code in layout
/* 
    // Add function on page 
    <?php $custom_options_theme = custom_options_theme(); ?>

    <?php if ( ! empty( $custom_options_theme['phone'] ) ): ?>
        <a href="tel:+<?php echo preg_replace( '/[^\d]/', '', $custom_options_theme['phone'] ); ?>">
            <?php echo $custom_options_theme['phone']; ?>
        </a>
    <?php endif; ?>

    <?php if ( ! empty( $custom_options_theme['facebook'] ) ): ?>
        <li>
            <a href="<?php echo $custom_options_theme['facebook'] ?>"></a>
        </li>
    <?php endif; ?>
*/