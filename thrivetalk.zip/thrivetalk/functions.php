<?php

// Сonnection styles and scripts
function custom_enqueue_select2() {
    // Connecting for admin and frontend
    wp_enqueue_script('select2-js', get_template_directory_uri() . '/assets/js/plugins/select2.min.js', array('jquery'), '4.0.13', true);
    wp_enqueue_style('select2-css', get_template_directory_uri() . '/assets/css/plugins/select2.min.css', array(), '4.0.13');
    
    // Connecting for only Frontend
    if (!is_admin()) {
        
        wp_enqueue_style('google-fonts', 'https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap');
        wp_enqueue_style( 'font-awesome', get_template_directory_uri() . '/assets/css/plugins/font-awesome-all.min.css');
        wp_enqueue_style('fancybox', get_template_directory_uri() . '/assets/css/plugins/fancybox.min.css');
        wp_enqueue_style('style', get_template_directory_uri() . '/assets/css/style.min.css', array(), '1.0.0');

        wp_deregister_script('jquery');
        wp_register_script('jquery', get_template_directory_uri() . '/assets/js/plugins/jquery-3.7.1.js', array(), '3.7.1', true);
        wp_enqueue_script('jquery');
        wp_enqueue_script('wp-link');
        wp_enqueue_script('lazyload', get_template_directory_uri() . '/assets/js/plugins/lazyload.min.js', array(), '1.0.0', true);
        wp_enqueue_script( 'fancybox', get_template_directory_uri() . '/assets/js/plugins/fancybox.min.js', array('jquery'), '3.5.7', true );
        wp_enqueue_script('slick-slider', get_template_directory_uri() . '/assets/js/plugins/slick.min.js', array('jquery'), '1.8.1', true);
        wp_enqueue_script('phones-mask', get_template_directory_uri() . '/assets/js/plugins/phones-mask.js', array('jquery'), '1.0.0', true);
        wp_enqueue_script('script', get_template_directory_uri() . '/assets/js/script.js', array('jquery'), '1.0.0', true);
    }
}

add_action('wp_enqueue_scripts', 'custom_enqueue_select2');
add_action('admin_enqueue_scripts', 'custom_enqueue_select2');

// Сonnecting other files
require_once get_template_directory() . '/incs/class-starter-navigation.php';
require_once get_template_directory() . '/incs/customizer.php';
require_once get_template_directory() . '/incs/home-slider-meta-box.php';
require_once get_template_directory() . '/templates/template-home-slider.php';

// Adding support for loading JSON files into ACF
add_filter('acf/settings/load_json', function($paths) {
    $paths[] = get_template_directory() . '/acf-json';
    return $paths;
});

// Permission to add these types of files to the media library.
add_filter( 'upload_mimes', 'upload_allow_types' );
function upload_allow_types( $mimes ) {

	$mimes['ico']  = 'image/vnd.microsoft.icon';
    $mimes['svg'] = 'image/svg+xml';

	return $mimes;
}

// Add need classes for body
function custom_body_classes( $classes ) {
    $classes[] = 'hidden';
    $classes[] = 'body-wrapper';

    return $classes;
}

add_filter( 'body_class', 'custom_body_classes' );

// Adding a field Theme Settings for ACF PRO
if( function_exists('acf_add_options_page') ) {
    acf_add_options_page(array(
        'page_title'    => 'Theme Settings',
        'menu_title'    => 'Theme Settings',
        'menu_slug'     => 'theme-settings',
        'capability'    => 'edit_theme_options',
        'redirect'      => false
    ));
}

// Add for form submission
function register_form_submission_post_type() {
    $labels = array(
        'name'               => 'Form Submissions',
        'singular_name'      => 'Form Submission',
        'menu_name'          => 'Form Submissions',
        'name_admin_bar'     => 'Form Submission',
        'add_new'            => 'Add New',
        'add_new_item'       => 'Add New Submission',
        'new_item'           => 'New Submission',
        'edit_item'          => 'Edit Submission',
        'view_item'          => 'View Submission',
        'all_items'          => 'All Submissions',
        'search_items'       => 'Search Submissions',
        'not_found'          => 'No submissions found.',
        'not_found_in_trash' => 'No submissions found in Trash.',
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable'  => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array('slug' => 'form_submission'),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 20,
        'supports'           => array('title', 'editor', 'custom-fields'),
    );

    register_post_type('form_submission', $args);
}
add_action('init', 'register_form_submission_post_type');

// Add new functions
add_action('after_setup_theme', function () {
    //    load_theme_textdomain('testdomain', get_template_directory() . '/languages');

    // Title for all pages
    add_theme_support( 'title-tag' );

    // Add image in posts (thumbnails)
    add_theme_support( 'post-thumbnails' );

    // Register menus
    register_nav_menus(
        array(
            'header-menu' => __('Header menu', 'testdomain'),
        )
    );
});


