<?php
/*
Template Name: Front page
*/
get_header(); ?>

<main class="main-wrapper main-top" id="home">

    <!-- Function to display home slider -->
    <?php custom_display_slider(); ?>
    <!-- Function to display home slider -->

    <?php 
        $why_title = get_field('why_title');
        $why_info = get_field('why_info');
        $why_image = get_field('why_image');

        if ($why_title || $why_info || !empty($why_image)): ?>
    <section class="section color-2">
        <div class="section__container">
            <div class="grid-x">
                <div class="cell small-12 medium-7 large-7">
                    <div class="section__wrap section__wrap-3">
                        <div class="section__info">
                            <?php if ($why_title): ?>
                            <h3 class="section__subtitle section__subtitle-2"><?php echo esc_html($why_title); ?></h3>
                            <?php endif; ?>

                            <?php if ($why_info): ?>
                            <div class="section__text section__text-3">
                                <?php echo $why_info; ?>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <?php if (!empty($why_image)): ?>
                <div class="cell small-12 medium-5 large-5">
                    <div class="section__img section__img-2">
                        <img src="<?php echo esc_url($why_image['url']); ?>"
                            alt="<?php echo esc_attr($why_image['alt']); ?>" />
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <?php if (get_field('tabs_title') || have_rows('tabs')): ?>
    <section class="wellness" id="wellness">
        <?php if ($tabs_title = get_field('tabs_title')): ?>
        <div class="grid-container">
            <div class="grid-x grid-padding-x">
                <div class="cell small-12 medium-12 large-12">
                    <div class="wellness__wrap">
                        <h2 class="wellness__title title"><?php echo esc_html($tabs_title); ?></h2>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <?php if (have_rows('tabs')): ?>
        <div class="wellness__tabs tabs">
            <div class="wellness__container grid-container">
                <div class="grid-x grid-padding-x">
                    <div class="cell small-12 medium-12 large-4">
                        <div class="tabs__btns">
                            <?php $i = 0; ?>
                            <?php while (have_rows('tabs')) : the_row(); ?>
                            <?php 
                                    $title = get_sub_field('title');
                                    ?>
                            <?php if ($title): ?>
                            <div class="tabs__btn <?php echo $i === 0 ? ' active' : ''; ?>">
                                <button><?php echo esc_html($title); ?></button>
                            </div>
                            <?php endif; ?>
                            <?php $i++; ?>
                            <?php endwhile; ?>
                        </div>
                    </div>
                    <div class="cell small-12 medium-12 large-8">
                        <div class="tabs__items">
                            <?php $i = 0; ?>
                            <?php while (have_rows('tabs')) : the_row(); ?>
                            <?php 
                                    $info = get_sub_field('info'); 
                                    ?>
                            <?php if ($info): ?>
                            <div class="tabs__item <?php echo $i === 0 ? ' active' : ''; ?>">
                                <div class="tabs__info">
                                    <div class="tabs__text">
                                        <?php echo $info; ?>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php $i++; ?>
                            <?php endwhile; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </section>
    <?php endif; ?>


    <?php
        if ( have_rows('gallery_slider') || get_field('gallery_title') ): ?>
    <section class="gallery" id="balance">

        <?php if ($gallery_title = get_field('gallery_title')): ?>
        <div class="grid-container">
            <div class="grid-x grid-padding-x">
                <div class="cell">
                    <div class="gallery__wrap">
                        <h2 class="gallery__wrap-title title"><?php echo esc_html($gallery_title); ?></h2>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <?php if ( have_rows('gallery_slider') ): ?>
        <div class="grid-container gallery__container">
            <div class="gallery__slider">
                <?php while ( have_rows('gallery_slider') ) : the_row(); ?>
                <div class="gallery__slider-wrap">
                    <div class="gallery__slide">
                        <div class="gallery__img">
                            <?php 
                                        $image = get_sub_field('image');
                                        if ( $image ): ?>
                            <img src="<?php echo esc_url($image['url']); ?>"
                                alt="<?php echo esc_attr($image['alt']); ?>">
                            <?php endif; ?>
                        </div>
                        <div class="gallery__info">
                            <?php 
                                        $title = get_sub_field('title');
                                        $info = get_sub_field('info');

                                        if ( $title ): ?>
                            <h3 class="gallery__title"><?php echo esc_html($title); ?></h3>
                            <?php endif; ?>

                            <?php if ( $info ): ?>
                            <p class="gallery__text"><?php echo esc_html($info); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
        </div>
        <?php endif; ?>
    </section>
    <?php endif; ?>

    <?php 
        $about_title = get_field('about_title');
        $about_info = get_field('about_info');

        if ($about_title || $about_info): ?>
    <section class="about-us" id="about-us">
        <div class="grid-container about-us__container">
            <div class="grid-x grid-padding-x">
                <?php if ($about_title): ?>
                <div class="cell small-12 medium-3 large-4">
                    <div class="about-us__wrap">
                        <h2 class="about-us__title"><?php echo esc_html($about_title); ?></h2>
                    </div>
                </div>
                <?php endif; ?>

                <?php if ($about_info): ?>
                <div class="cell small-12 medium-9 large-8">
                    <div class="about-us__info">
                        <p class="about-us__text"><?php echo esc_html($about_info); ?></p>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <?php 
        if ( get_field('help_title') || have_rows('services_1') ): ?>
    <section class="help" id="services">
        <div class="box">
            <?php if ( get_field('help_title') ): ?>
            <div class="grid-container">
                <div class="grid-x grid-padding-x">
                    <div class="cell">
                        <h2 class="help__title title"><?php echo esc_html( get_field('help_title') ); ?></h2>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <?php if ( have_rows('services_1') ): ?>
            <div class="help__container box__container">
                <div class="grid-x">
                    <?php 
                                $counter = 1;
                                while ( have_rows('services_1') ) : the_row(); 
                                    $title = get_sub_field('title');
                                    $image = get_sub_field('image');

                                    if ( $title || $image ): ?>
                    <div class="cell small-12 medium-6 large-3">
                        <div class="box__wrap box__wrap-<?php echo $counter; ?>">
                            <?php if ( $title ): ?>
                            <div class="box__title">
                                <h3 class="box__title-wrap"><?php echo esc_html( $title ); ?></h3>
                            </div>
                            <?php endif; ?>

                            <?php if ( $image ): ?>
                            <div class="box__img">
                                <img src="<?php echo esc_url( $image['url'] ); ?>"
                                    alt="<?php echo esc_attr( $image['alt'] ); ?>">
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php $counter++; ?>
                    <?php endwhile; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </section>
    <?php endif; ?>

    <?php if ( have_rows('services_2') ): ?>
    <section class="box">
        <div class="box__container">
            <div class="grid-x">
                <?php 
                        $counter = 1;
                        while ( have_rows('services_2') ) : the_row(); 
                            $title = get_sub_field('title');
                            $image = get_sub_field('image');

                            if ( $title || $image ): ?>
                <div class="cell small-12 medium-6 large-4">
                    <div class="box__wrap box__wrap-<?php echo $counter; ?>">
                        <?php if ( $title ): ?>
                        <div class="box__title">
                            <h3 class="box__title-wrap"><?php echo esc_html( $title ); ?></h3>
                        </div>
                        <?php endif; ?>

                        <?php if ( $image ): ?>
                        <div class="box__img">
                            <img src="<?php echo esc_url( $image['url'] ); ?>"
                                alt="<?php echo esc_attr( $image['alt'] ); ?>">
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
                <?php $counter++; ?>
                <?php endwhile; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <?php
        if( have_rows('program') ): ?>
    <section class="block">
        <div class="block__container full-container">
            <div class="grid-x grid-padding-x">
                <?php while( have_rows('program') ): the_row(); 
                            $title = get_sub_field('title');
                            $info = get_sub_field('info');
                        ?>
                <div class="cell small-12 medium-6 large-4">
                    <div class="block__wrap">
                        <?php if ($title): ?>
                        <h3 class="block__title">
                            <?php echo $title; ?>
                        </h3>
                        <?php endif; ?>
                        <?php if ($info): ?>
                        <div class="block__info">
                            <p class="block__text">
                                <?php echo $info; ?>
                            </p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <?php 
    $reach_info = get_field('reach_info');
    $reach_bg = get_field('reach_bg');
    
    if ($reach_info || $reach_bg): ?>
        <section class="reach" id="reach" style="background-image: url('<?php echo $reach_bg; ?>');">
            <div class="grid-container">
                <div class="grid-x grid-padding-x">
                    <div class="cell small-12 medium-6 large-8">
                        <div class="reach__wrap">
                            <div class="reach__info">
                                <?php echo $reach_info; ?>
                            </div>
                        </div>
                    </div>
                    <div class="cell small-12 medium-6 large-4">
                        <div class="reach__wrap">
                            <form action="<?php echo get_template_directory_uri(); ?>/process_form.php" method="post"
                                class="form">
                                <div class="form__wrap">
                                    <label for="name" class="form__label"><?php _e('Name', 'default'); ?></label>
                                    <input type="text" id="name" name="name" placeholder="<?php _e('Name', 'default'); ?>"
                                        required autocomplete="off" class="form__input">
                                </div>
                                <div class="form__wrap">
                                    <label for="email" class="form__label"><?php _e('Email', 'default'); ?></label>
                                    <input type="email" id="email" name="email"
                                        placeholder="<?php _e('Email', 'default'); ?>" required autocomplete="off"
                                        class="form__input">
                                </div>
                                <div class="form__wrap">
                                    <label for="phone" class="form__label"><?php _e('Phone Number', 'default'); ?></label>
                                    <input type="tel" id="phone" name="phone" required
                                        placeholder="<?php _e('Phone Number', 'default'); ?>" autocomplete="off"
                                        class="form__input phone">
                                </div>
                                <div class="form__btn btn">
                                    <button type="submit" class="btn__wrap"><?php _e('Subscribe', 'default'); ?></button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    <?php endif; ?>

    <?php
    $section_title = get_field('section_title');
    $section_text = get_field('section_text');
    $button_text = get_field('button_text');
    $section_image = get_field('section_image');

    if ($section_title || $section_text || $button_text || $section_image): ?>
    <section class="section" id="blog">
        <div class="section__container">
            <div class="grid-x section__row-reverse">
                <div class="cell small-12 medium-7 large-8">
                    <div class="section__wrap">

                        <?php if ($section_title): ?>
                        <h2 class="section__title"><?php echo esc_html($section_title); ?></h2>
                        <?php endif; ?>

                        <?php if ($section_text): ?>
                        <div class="section__info">
                            <div class="section__text">
                                <?php echo $section_text; ?>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if ($button_text): ?>
                        <div class="section__btn btn-3">
                            <button class="btn-3__wrap" data-fancybox
                                data-src="#dialog-content"><?php echo esc_html($button_text); ?></button>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php if ($section_image): ?>
                <div class="cell small-12 medium-5 large-4">
                    <div class="section__img">
                        <img src="<?php echo esc_url($section_image['url']); ?>"
                            alt="<?php echo esc_attr($section_image['alt']); ?>">
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <?php
    $section_title_2 = get_field('section_title_2');
    $section_subtitle_2 = get_field('section_subtitle_2');
    $section_text_2 = get_field('section_text_2');
    $button_text_2 = get_field('button_text_2');
    $section_image_2 = get_field('section_image_2');

    if ($section_title_2 || $section_subtitle_2 || $section_text_2 || $button_text_2 || $section_image_2): ?>
    <section class="section color-1">
        <div class="section__container">
            <div class="grid-x">
                <div class="cell small-12 medium-7 large-8">
                    <div class="section__wrap section__wrap-2">

                        <?php if ($section_title_2): ?>
                        <h2 class="section__title section__title-2"><?php echo esc_html($section_title_2); ?></h2>
                        <?php endif; ?>

                        <?php if ($section_subtitle_2): ?>
                        <h3 class="section__subtitle"><?php echo esc_html($section_subtitle_2); ?></h3>
                        <?php endif; ?>

                        <?php if ($section_text_2): ?>
                        <div class="section__info">
                            <div class="section__text section__text-2"><?php echo $section_text_2; ?></div>
                        </div>
                        <?php endif; ?>

                        <?php if ($button_text_2): ?>
                        <div class="section__btn section__btn-2 btn-2">
                            <button class="btn-2__wrap" data-fancybox
                                data-src="#dialog-content"><?php echo esc_html($button_text_2); ?></button>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if ($section_image_2): ?>
                <div class="cell small-12 medium-5 large-4">
                    <div class="section__img section__img-1">
                        <img src="<?php echo esc_url($section_image_2['url']); ?>"
                            alt="<?php echo esc_attr($section_image_2['alt']); ?>">
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <?php if (get_field('faq_title') || have_rows('faq_accordion')) : ?>
    <section class="faq" id="faq">
        <?php if (get_field('faq_title')) : ?>
        <div class="grid-container">
            <div class="grid-x grid-padding-x">
                <div class="cell small-12 medium-12 large-12">
                    <div class="faq__wrap">
                        <h2 class="faq__title title"><?php echo esc_html(get_field('faq_title')); ?></h2>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <?php
        $accordion_icon = get_field('accordion_icon');
        if( have_rows('faq_accordion') ): ?>
        <div class="grid-container">
            <div class="grid-x grid-padding-x">
                <div class="cell small-12 medium-12 large-12">
                    <div class="faq__wrapper">
                        <div class="accordion">
                            <div class="accordion__container">
                                <?php while( have_rows('faq_accordion') ): the_row(); 
                                        $title = get_sub_field('title');
                                        $info = get_sub_field('info');
                                    ?>
                                <div class="accordion__wrap">
                                    <div class="accordion__title">
                                        <?php if ($title): ?>
                                        <h3 class="accordion__title-wrap">
                                            <?php echo $title; ?>
                                        </h3>
                                        <?php endif; ?>
                                        <?php if ($accordion_icon): ?>
                                        <div class="accordion__icon">
                                            <img src="<?php echo esc_url($accordion_icon['url']); ?>"
                                                alt="<?php echo esc_attr($accordion_icon['alt']); ?>" />
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    <?php if ($info): ?>
                                    <div class="accordion__info">
                                        <div class="accordion__text">
                                            <?php echo $info; ?>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <?php endwhile; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </section>
    <?php endif; ?>

</main>

<?php get_footer(); ?>