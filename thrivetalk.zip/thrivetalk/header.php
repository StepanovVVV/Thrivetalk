<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head class="">
    <meta charset="<?php bloginfo( 'charset' ) ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?> class="hidden body-wrapper" id="content">
    <?php wp_body_open(); ?>
    <header class="header">
        <div class="header__container grid-container">
            <div class="header__logo">
                <a href="<?php echo home_url( '/' ) ?>">
                    <?php if ($logo = get_field('logo', 'options')) : ?>
                        <img src="<?php echo esc_url($logo['url']); ?>" alt="<?php echo esc_attr($logo['alt']); ?>" />
                    <?php else : ?>
                        <h1 class="header__title"><?php echo get_bloginfo('name'); ?></h1>
                    <?php endif; ?>
                </a>
            </div>
            <div class="header__burger">
                <span></span>
            </div>
            <div class="header__menu">
                <nav class="header__nav">
                    <?php 
                        wp_nav_menu(array(
                            'theme_location' => 'header-menu',
                            'container' => 'false',
                            'menu_class' => 'header__items',
                            'walker' => new Starter_Navigation(),
                        ));
                    ?>
                </nav>
                <div class="header__btn btn">
                    <button class="btn__wrap" data-fancybox data-src="#dialog-content"><?php echo __('CONTACT US', 'default'); ?></button>
                </div>

                <div class="header__overlay"></div>
            </div>
        </div>
    </header>