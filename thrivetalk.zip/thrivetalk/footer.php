<?php 
$footer_image = get_field('image', 'options');
$footer_subtitle_1 = get_field('footer_subtitle_1', 'options');
$footer_info = get_field('footer_info', 'options');
$footer_subtitle_2 = get_field('footer_subtitle_2', 'options');
$address = get_field('address', 'options');
$phone = get_field('phone', 'options');
$email = get_field('email', 'options');
$footer_subtitle_3 = get_field('footer_subtitle_3', 'options');
$office_hours = get_field('office_hours', 'options');
$copyright = get_field('copyright', 'options');
$socials = get_field('socials', 'options');

if ($footer_image || $footer_subtitle_1 || $footer_info || $footer_subtitle_2 || $address || $phone || $email || $footer_subtitle_3 || $office_hours || $copyright || $socials): ?>
    <footer class="footer">
        <div class="footer__container">
            <div class="grid-x">
                <?php if( !empty( $footer_image ) ): ?>
                <div class="cell small-12 medium-5 large-5">
                    <div class="footer__wrap">
                        <div class="footer__logo">
                            <img src="<?php echo esc_url($footer_image['url']); ?>" alt="<?php echo esc_attr($footer_image['alt']); ?>" />
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <div class="cell small-12 medium-7 large-7 footer__info">
                    <div class="grid-x">
                        <?php if ($footer_subtitle_1 || $footer_info): ?>
                        <div class="cell small-12 medium-12 large-4">
                            <div class="footer__wrap">
                                <?php if ($footer_subtitle_1): ?>
                                    <h4 class="footer__title"><?php echo $footer_subtitle_1; ?></h4>
                                <?php endif; ?>
                                <?php if ($footer_info): ?>
                                    <div class="footer__nav">
                                        <p class="footer__text">
                                            <?php echo $footer_info; ?>
                                        </p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endif; ?>

                        <div class="cell small-12 medium-6 large-4">
                            <div class="footer__wrap">
                                <?php if ($footer_subtitle_2): ?>
                                <h4 class="footer__title"><?php echo $footer_subtitle_2; ?></h4>
                                <?php endif; ?>
                                <nav class="footer__nav">
                                    <ul class="footer__items">
                                        <?php if ($address): ?>
                                            <li class="footer__item">
                                                <a href="<?php echo esc_url( $address['url'] ); ?>" target="<?php echo esc_attr( $address['target'] ? $address['target'] : '_self' ); ?>" class="footer__link">
                                                    <?php echo esc_html( $address['title'] ); ?>
                                                </a>
                                            </li>
                                        <?php endif; ?>
                                        <?php if ($phone): ?>
                                            <?php $clean_phone = preg_replace('/\D/', '', $phone); ?>
                                            <li class="footer__item footer__phone">
                                                <a href="tel:+<?php echo esc_attr($clean_phone); ?>" class="footer__link"><?php echo esc_html($phone); ?></a>
                                            </li>
                                        <?php endif; ?>
                                        <?php if ($email): ?>
                                            <li class="footer__item footer__email">
                                                <a href="mailto:<?php echo esc_html($email); ?>" class="footer__link"><?php echo esc_html($email); ?></a>
                                            </li>
                                        <?php endif; ?>
                                    </ul>
                                </nav>
                            </div>
                        </div>

                        <div class="cell small-12 medium-6 large-4">
                            <div class="footer__wrap footer__position">
                                <?php if ($footer_subtitle_3): ?>
                                <h4 class="footer__title"><?php echo $footer_subtitle_3; ?></h4>
                                <?php endif; ?>
                                <?php if ($office_hours): ?>
                                <nav class="footer__nav">
                                    <?php echo $office_hours; ?>
                                </nav>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="footer__copy">
            <div class="grid-container">
                <div class="grid-x grid-padding-x">
                    <?php if ($copyright): ?>
                        <div class="cell large-6 small-12">
                            <div class="footer__wrap">
                                <div class="footer__copy-text">
                                    <?php echo $copyright; ?>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if ($socials): ?>
                        <div class="cell large-6 small-12">
                            <div class="footer__wrap">
                                <div class="socials-position">
                                    <?php get_template_part('parts/socials'); ?>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </footer>
<?php endif; ?>

    <!-- Pop-up -->
    <div id="dialog-content" class="popup">
        <div class="popup__container">
            <div class="popup__wrapper">
                <div class="popup__content">
                    <h3 class="popup__title"><?php _e('Contact us now', 'default'); ?></h3>
                    <p class="popup__info"><?php _e('Our manager will contact you as soon as possible.', 'default'); ?></p>
                </div>
                <div class="popup__form">
                    <form action="<?php echo get_template_directory_uri(); ?>/process_form.php" method="post" class="form">
                        <div class="form__wrap">
                            <label for="name-2" class="form__label"><?php _e('Name', 'default'); ?></label>
                            <input type="text" id="name-2" name="name" placeholder="<?php _e('Name', 'default'); ?>" required autocomplete="off" class="form__input">
                        </div>
                        <div class="form__wrap">
                            <label for="email-2" class="form__label"><?php _e('Email', 'default'); ?></label>
                            <input type="email" id="email-2" name="email" placeholder="<?php _e('Email', 'default'); ?>" required autocomplete="off" class="form__input">
                        </div>
                        <div class="form__wrap">
                            <label for="phone-2" class="form__label"><?php _e('Phone Number', 'default'); ?></label>
                            <input type="tel" id="phone-2" name="phone" required placeholder="<?php _e('Phone Number', 'default'); ?>" autocomplete="off" class="form__input phone">
                        </div>
                        <div class="form__btn btn">
                            <button type="submit" class="btn__wrap"><?php _e('Subscribe', 'default'); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php wp_footer(); ?>
</body>

</html>