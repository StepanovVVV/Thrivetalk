<?php
/**
 * Page
*/
get_header(); ?>

	<main class="main-wrapper main-top">
		<div class="grid-container">
			<div class="grid-x grid-padding-x">
				<div class="large-12 medium-12 small-12 cell">
					<?php if ( have_posts() ) : ?>
						<?php while ( have_posts() ) : the_post(); ?>
							<article <?php post_class( '' ); ?>>
								<h1><?php the_title(); ?></h1>
								<?php if ( has_post_thumbnail() ) : ?>
									<div title="<?php the_title_attribute(); ?>">
										<?php the_post_thumbnail( 'large' ); ?>
									</div>
								<?php endif; ?>
								<div>
									<?php the_content( '', true ); ?>
								</div>
							</article>
						<?php endwhile; ?>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</main>

<?php get_footer(); ?>
